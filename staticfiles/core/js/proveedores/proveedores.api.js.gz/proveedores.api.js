/**
 * proveedores.api.js - Capa de Datos Proveedores v2.61
 * [INFO] Auditor ACE: Retorna siempre {ok, status, data} compatible con UIManager.
 */
(function (w) {
  'use strict';

  const API_URL = '/api/v1/proveedores/';

  /**
   * Normalización Zero Trust de Payloads
   */
  function normalizePayload(data) {
    const p = Object.assign({}, data || {});
    
    // Normalización de IDs/NITs
    const nit = String(p.nit || p.numero_documento || '').trim();
    p.numero_documento = nit;
    p.nit = nit;

    // Normalización de booleanos
    const bools = ['responsable_iva', 'gran_contribuyente', 'autoretenedor', 'activo'];
    bools.forEach(f => {
      if (p[f] !== undefined) {
        p[f] = (p[f] === true || p[f] === 'true' || p[f] === 'on' || p[f] === 1);
      }
    });

    return p;
  }

  const proveedoresAPI = {
    list: (params) => w.http('GET', API_URL, params),
    get: (id) => w.http('GET', `${API_URL}${id}/`),
    create: (data) => w.http('POST', API_URL, normalizePayload(data)),
    update: (id, data) => w.http('PATCH', `${API_URL}${id}/`, normalizePayload(data)),
    delete: (id) => w.http('DELETE', `${API_URL}${id}/`)
  };

  w.proveedoresAPI = proveedoresAPI;

})(window);
